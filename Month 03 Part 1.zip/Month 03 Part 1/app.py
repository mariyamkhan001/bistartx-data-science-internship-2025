# lightweight_hybrid_rec.py
# Flask app with lightweight hybrid movie recommendation logic

from flask import Flask, request, render_template
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import numpy as np

app = Flask(__name__)

# Load movie data (local CSV instead of external API or Surprise)
movies = pd.read_csv("movies.csv")  # Ensure this file is uploaded on PythonAnywhere
movies['combined'] = movies['overview'].fillna('') + ' ' + movies['genres'].fillna('')

# TF-IDF content-based vectorizer
vectorizer = TfidfVectorizer(stop_words='english')
tfidf_matrix = vectorizer.fit_transform(movies['combined'])

# Dummy user interaction history (simulate collaborative behavior)
user_history = {
    "user1": [1, 7, 10],  # movie IDs the user liked
    "user2": [3, 5, 20],
}

def get_similar_movies(movie_ids, top_n=5):
    idxs = [movies[movies['id'] == mid].index[0] for mid in movie_ids if mid in movies['id'].values]
    sim_scores = np.mean([cosine_similarity(tfidf_matrix[i], tfidf_matrix).flatten() for i in idxs], axis=0)
    sim_indices = sim_scores.argsort()[-top_n-1:][::-1]
    return movies.iloc[sim_indices][['title', 'id']].head(top_n)

@app.route("/", methods=["GET", "POST"])
def home():
    if request.method == "POST":
        user = request.form.get("user")
        liked = request.form.getlist("liked")
        liked = list(map(int, liked)) if liked else user_history.get(user, [])
        recommendations = get_similar_movies(liked)
        return render_template("recommend.html", user=user, recs=recommendations.to_dict(orient="records"))
    return render_template("index.html")

if __name__ == "__main__":
    app.run(debug=True)
